package ctrlstmt;

public class FahrenheittoCelsius {

	public static void main(String[] args) {
		
		        float fahrenheit = 98.6f;  
		        float celsius = (fahrenheit - 32) * 5 / 9;   
		      System.out.println("Temperature in Fahrenheit: " + fahrenheit);
		        System.out.println("Temperature in Celsius: " + celsius);
		    }
		}


