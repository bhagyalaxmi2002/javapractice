package ctrlstmt;

public class Leapyear {

	public static void main(String[] args) {
		int year = 2024;
		if(year%4==0) {
			System.out.println("Leap year");
		}
		else {
			System.out.println("Not a leap year");
		}

	}

}
