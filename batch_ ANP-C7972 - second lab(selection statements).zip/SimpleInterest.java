package ctrlstmt;

public class SimpleInterest {

	public static void main(String[] args) {
		 double principal = 15000;  
		 double rate = 5;          
	        int time = 2;            

	        
	        double simpleInterest = (principal * rate * time) / 100;

	        
	        System.out.println("The Simple Interest is: " + simpleInterest);


	}

}
